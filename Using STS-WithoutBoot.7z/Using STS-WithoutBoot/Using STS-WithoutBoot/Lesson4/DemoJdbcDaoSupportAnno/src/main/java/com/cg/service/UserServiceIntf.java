package com.cg.service;

import java.util.List;

import com.cg.bean.User;

public interface UserServiceIntf {
	public List<User> displayUsers();

}
