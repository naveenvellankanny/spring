package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Student;
import com.cg.studentservice.StudentService;

@RestController
public class StudentController {
	@Autowired
	StudentService service;
	@Autowired
    Student stu;
	@PostMapping(value="/createStudent",consumes= {MediaType.APPLICATION_JSON_VALUE})
	public Student CreateStudent(@RequestBody Student student) {
		Student req=service.CreateStudent(student);
		return req; 
		
	}
	
	@PutMapping(value="/update",consumes= {MediaType.APPLICATION_JSON_VALUE})
	public String updateStudent(@RequestBody Student student) {
		Student rej=service.updateStudent(student);
		return "id" +student.getId() +":it is updated";
}
	@GetMapping(value="/student",consumes= {MediaType.APPLICATION_JSON_VALUE})
	public List<Student> viewlist(){
		return service.viewlist();
		 
	}
	
	@DeleteMapping(value="/deleteemployee/{id}")
	  public String deletebyid(@PathVariable int id){
		service.deleteById(id);
		return "id:" +id +"->deleted";
	}
	@GetMapping(value="/findAll/{id}")
	public  Student findid(@PathVariable int id) {
	 return service.findAllById(id);
	
	}
}