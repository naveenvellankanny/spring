package com.cg.studentservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.StudentDao.EmployeeDao;
import com.cg.bean.Student;
@Service
public class StudentService {
@Autowired
  EmployeeDao employeedao;

	public Student CreateStudent(Student student) {
		return employeedao.save(student);
	}

	public Student updateStudent(Student student) {
		return employeedao.save(student);
	}

	public List<Student> viewlist() {
		return employeedao.findAll();
	}

	public void deleteById(int id) {
		employeedao.deleteById(id);
		
	}

	public Student findAllById(int id) {
	 return employeedao.findById(id).get(); 
	}
}
