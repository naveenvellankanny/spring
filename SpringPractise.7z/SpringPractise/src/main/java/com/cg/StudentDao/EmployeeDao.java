package com.cg.StudentDao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.bean.Student;

public interface EmployeeDao extends JpaRepository<Student,Integer> {

	






	

}
